# Test > 2025-01-16 10:53am
https://universe.roboflow.com/powerline-obstruction-detection/test-kpzbb

Provided by a Roboflow user
License: CC BY 4.0

